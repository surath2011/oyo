package com.oyorooms.bookroomscripts;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.oyorooms.businessLib.GuestDetails;
import com.oyorooms.businessLib.Homepage;
import com.oyorooms.businessLib.SearchResult;
import com.oyorooms.genericLib.DriverSetup;
import com.oyorooms.genericLib.ExcelLib;
import com.oyorooms.genericLib.WebdriverCommonLib;
import com.oyorooms.genericLib.configFileSetup;

public class BookRoom extends DriverSetup {
	
	//String filePath = System.getProperty("user.dir")+"\\TestData\\TestDataSheet.xlsx";
	//String sheetName ="TestData";
	//String colName = "actualText";
	//int rowNum = 1;
	Homepage homepage = new Homepage();
	SearchResult searchPage = new SearchResult();
	GuestDetails guestDtls = new GuestDetails();
	configFileSetup conFile = new configFileSetup();
	WebdriverCommonLib wLib = new WebdriverCommonLib();
	ExcelLib  td = new ExcelLib();
	

	@BeforeMethod
	public void configBeforeMethod() throws IOException {
		setDriver(conFile.getValue("url"), "chrome");
		
	}

	@Test
	public void bookRoomTest() throws InterruptedException, IOException {
		System.out.println("Inside Test");
		//String actualText = td.getCellData(filePath, sheetName, "actualText", 2);
		//System.out.println(actualText);
		homepage.searchCity(getDriver(), conFile.getValue("city"));
		homepage.dateSelection(getDriver());
		homepage.guestSelection(getDriver());
		homepage.clickSerchBtn(getDriver());
		
		searchPage.clickBookNow(getDriver());
		
		wLib.switchToNextWindow(getDriver());
		
		
		
		guestDtls.enterGuestDetsils(getDriver());
		
		
		Thread.sleep(10000);
		boolean sendpasscodebtnstatus=guestDtls.checksendPasscode(getDriver());
		
		String expectedstatus=conFile.getValue("expectedbtnstatus");
		
		Boolean expstatus=Boolean.parseBoolean(expectedstatus);
		
		
		if(expstatus==sendpasscodebtnstatus) {
			System.out.println("Test Passed");
		}
		else {
			
			System.out.println("Test Failed");
		}
		 
	}

	@AfterMethod
	public void afterMethodConfig() {
		getDriver().close();
		getDriver().quit();
	}

}
