package com.oyorooms.genericLib;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebdriverCommonLib {

	public void waitforElementTobepresent(WebDriver driver, String xpath) {
		WebDriverWait wait = new WebDriverWait(driver, 40) ;
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
	}
	
	public void switchToNextWindow(WebDriver driver) {
		String chWin="";
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			chWin = itr.next();
		}
		System.out.println(chWin);
		driver.switchTo().window(chWin);
	}
	
}
