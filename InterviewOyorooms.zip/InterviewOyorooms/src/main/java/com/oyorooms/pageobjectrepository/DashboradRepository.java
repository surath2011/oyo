package com.oyorooms.pageobjectrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class DashboradRepository {
@FindBy(id="autoComplete__home")
WebElement autocommpleteSrchTextBox;

public WebElement getautocompleteSrchTextBox() {
	return autocommpleteSrchTextBox;
}

@FindBy(xpath="//div[@class='d-popup geoSuggestionsList']//span")
WebElement suggestionList;

public WebElement getsuggestionList() {
	return suggestionList;
}

@FindBy(xpath="//div[@class='oyo-row oyo-row--no-spacing datePickerDesktop datePickerDesktop--home']/div")
WebElement datePicker;

public WebElement getDatePicker() {
	return datePicker;
}
@FindBy(xpath="(//span[contains(text(),'27')])[2]")
WebElement date27;

public WebElement getDate27() {
	return date27;
}

@FindBy(xpath="(//span[contains(text(),'29')])[2]")
WebElement date29;

public WebElement getDate29() {
	return date29;
}
@FindBy(xpath="//button[contains(text(),'Search')]")
WebElement searchBtn;

public WebElement getSearchBtn() {
	return searchBtn;
}
@FindBy(xpath="//div[contains(text(),'Room')]")
WebElement guestTextBox;

public WebElement getGuestTextbox() {
	return guestTextBox;
}
@FindBy(xpath="//span[@class='d-text16 guestRoomPickerPopUp__count']")
WebElement guestCount;

public WebElement getguestCount() {
	return guestCount;
}

@FindBy(xpath="//span[contains(text(),'Room')]/../following-sibling::div//span[3]")
WebElement minusBtn;

public WebElement getMinusBtn() {
	return minusBtn;
}


	
}
