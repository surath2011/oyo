package com.oyorooms.pageobjectrepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GuestDetailsRepository {
	@FindBy(id="name")
	WebElement userName;

	public WebElement getUserName() {
		return userName;
	}
	
	@FindBy(xpath="//input[@countrycode='+91']")
	WebElement phoneNo;

	public WebElement getPhoneNo() {
		return phoneNo;
	}
	
	@FindBy(id="email")
	WebElement userEmailId;

	public WebElement getuserEmailId() {
		return userEmailId;
	}

	@FindBy(xpath="//button[@class='c-c2mqcb']")
	WebElement sendPasscode;

	public WebElement getsendPasscodebtn() {
		return sendPasscode;
	}
	@FindBy(xpath="//button[@disabled class='c-c2mqcb']")
	WebElement sendPasscodedis;

	public WebElement getsendPasscodebtndis() {
		return sendPasscodedis;
	}
	
	
}
