package com.oyorooms.businessLib;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.oyorooms.genericLib.configFileSetup;
import com.oyorooms.pageobjectrepository.GuestDetailsRepository;

public class GuestDetails {
	configFileSetup conFile = new configFileSetup();

	public void enterGuestDetsils(WebDriver driver) throws IOException {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		guest.getUserName().sendKeys(conFile.getValue("UserName"));
		
		guest.getPhoneNo().sendKeys(conFile.getValue("phone"));
		
		guest.getuserEmailId().sendKeys(conFile.getValue("mailId"));
		
	}
	
	public boolean checksendPasscode(WebDriver driver) {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		boolean btnstatus=guest.getsendPasscodebtn().isDisplayed();
		return btnstatus;
	}
	public boolean getsendPasscodebtndis(WebDriver driver) {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		boolean btnstatus=guest.getsendPasscodebtndis().isDisplayed();
		return btnstatus;
	}
	/*public String getPayAtHotelTextFromConfirmationWindow(WebDriver driver) {
		GuestDetailsRepository guest =PageFactory.initElements(driver, GuestDetailsRepository.class);
		return guest.getpayAtHotelTextfromConfirmationWindow().getText();
	}*/
}
