package com.oyorooms.businessLib;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.oyorooms.pageobjectrepository.SearchResultRepository;

public class SearchResult {

	public void clickBookNow(WebDriver driver) {
		SearchResultRepository search = PageFactory.initElements(driver, SearchResultRepository.class);
		search.getBookNowBtn().click();
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
}
