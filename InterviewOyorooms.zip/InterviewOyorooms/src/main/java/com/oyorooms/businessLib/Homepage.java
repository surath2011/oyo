package com.oyorooms.businessLib;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.oyorooms.pageobjectrepository.DashboradRepository;


public class Homepage {
	/* Method to search a city */
	public void searchCity(WebDriver driver, String city ) throws InterruptedException {
		DashboradRepository dashbd = PageFactory.initElements(driver, DashboradRepository.class);
		dashbd.getautocompleteSrchTextBox().sendKeys(city);
		
		dashbd.getsuggestionList().click();
		
	}
	
	public void clickSerchBtn(WebDriver driver) {
		DashboradRepository dashbd = PageFactory.initElements(driver, DashboradRepository.class);
		dashbd.getSearchBtn().click();
		System.out.println("Srcbtn clicked");
		
	}
	
	public void dateSelection(WebDriver driver) {
		DashboradRepository dashbd = PageFactory.initElements(driver, DashboradRepository.class);
		dashbd.getDatePicker().click();
		dashbd.getDate27().click();
		dashbd.getDate29().click();
		System.out.println("Date selected");
		
	}
	
	
	public void guestSelection(WebDriver driver) throws InterruptedException {
		DashboradRepository dashbd = PageFactory.initElements(driver, DashboradRepository.class);
		dashbd.getGuestTextbox().click();
		String roomCoutn=dashbd.getguestCount().getText();
		System.out.println("Room Count:"+roomCoutn);
		
		/*WebElement minus = dashbd.getMinusBtn();
		do {
			minus.click();
		}while(roomCoutn.equals(String.valueOf(1)));
		System.out.println("Minus btn clicked");*/
		
	}
	
	
	
	
}
